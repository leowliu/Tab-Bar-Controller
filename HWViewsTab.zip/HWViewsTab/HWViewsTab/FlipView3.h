//
//  FlipView3.h
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlipView3 : UIView {
    UIImageView *imageFlipView3;
}

@end

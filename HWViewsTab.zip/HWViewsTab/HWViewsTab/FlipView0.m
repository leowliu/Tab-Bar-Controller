//
//  FlipView0.m
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FlipView0.h"

@implementation FlipView0

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor redColor];
        CGRect f = CGRectMake(40, 80, 240, 240);
        imageFlipView0 = [[UIImageView alloc] initWithFrame: f];
        [imageFlipView0 setImage:[UIImage imageNamed: @"PSM_Smiley_face_decal.png"]];
        imageFlipView0.opaque = YES;
        [self addSubview: imageFlipView0];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
    [super dealloc];
}

@end

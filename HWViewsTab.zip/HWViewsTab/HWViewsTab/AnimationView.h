//
//  AnimationView.h
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimationView : UIView {
    UIView *view;
    UIImageView *imageView;
}

@end

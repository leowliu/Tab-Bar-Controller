//
//  FlipView2.h
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlipView2 : UIView {
    UIImageView *imageFlipView2;
}

@end

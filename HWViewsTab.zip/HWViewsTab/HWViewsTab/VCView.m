//
//  VCView.m
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "VCView.h"

@implementation VCView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor yellowColor];
		
		//Create the leave in the upper left corner of this View.
		frame = CGRectMake(0, 0, 60, 60);
        leave1 = [[UIImageView alloc] initWithFrame: frame];
        [leave1 setImage:[UIImage imageNamed: @"a_Maple_Leaf_Single.gif"]];
        leave1.opaque = YES;
		leave1.backgroundColor = [UIColor clearColor];
		[self addSubview: leave1];
        
        frame = CGRectMake(40, 30, 60, 60);
        leave2 = [[UIImageView alloc] initWithFrame: frame];
        [leave2 setImage:[UIImage imageNamed: @"a_Maple_Leaf_Single.gif"]];
        leave2.opaque = YES;
		leave2.backgroundColor = [UIColor clearColor];
		[self addSubview: leave2];
        
        frame = CGRectMake(80, 60, 60, 60);
        leave3 = [[UIImageView alloc] initWithFrame: frame];
        [leave3 setImage:[UIImage imageNamed: @"a_Maple_Leaf_Single.gif"]];
        leave3.opaque = YES;
		leave3.backgroundColor = [UIColor clearColor];
		[self addSubview: leave3];
        
        frame = CGRectMake(120, 90, 60, 60);
        leave4 = [[UIImageView alloc] initWithFrame: frame];
        [leave4 setImage:[UIImage imageNamed: @"a_Maple_Leaf_Single.gif"]];
        leave4.opaque = YES;
		leave4.backgroundColor = [UIColor clearColor];
		[self addSubview: leave4];
        
        rotation = .5;
        cntr = 0;
        pos = 1;
		//Ball initially moves to lower right.
		dx = 3;
		dy = 3;
    }
    return self;
}

- (void) bounce {	
	//Where the ball would be if its horizontal motion were allowed
	//to continue for one more move.
	CGRect horizontal = leave1.frame;
	horizontal.origin.x += dx;
    
    horizontal = leave2.frame;
	horizontal.origin.x += dx;
    
    horizontal = leave3.frame;
	horizontal.origin.x += dx;
    
    horizontal = leave3.frame;
	horizontal.origin.x += dx;
    
	//Where the ball would be if its vertical motion were allowed
	//to continue for one more move.
	CGRect vertical = leave1.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = leave2.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = leave3.frame;
	vertical.origin.y += (dy * pos);
    
    vertical = leave4.frame;
	vertical.origin.y += (dy * pos);
    
	//Ball must remain inside self.bounds.
	if (!CGRectEqualToRect(horizontal, CGRectIntersection(horizontal, self.bounds))) {
		//Ball will bounce off left or right edge of View.
		dx = -dx;
	}
    
	if (!CGRectEqualToRect(vertical, CGRectIntersection(vertical, self.bounds))) {
		//Ball will bounce off top or bottom edge of View.
		dy = -dy;
	}
	
}

- (void) move: (CADisplayLink *) displayLink {
    
    //NSLog(@"leave.center.x: %f", leave.center.x);
    //NSLog(@"leave.center.y: %f", leave.center.y);
	leave1.center = CGPointMake(leave1.center.x + dx, leave1.center.y + (dy * pos));
    leave2.center = CGPointMake(leave2.center.x + dx, leave2.center.y + (dy * pos));
    leave3.center = CGPointMake(leave3.center.x + dx, leave3.center.y + (dy * pos));
    leave4.center = CGPointMake(leave4.center.x + dx, leave4.center.y + (dy * pos));
    cntr += 1;
    //NSLog(@"counter: %f", counter);
    //if (counter >= 5) {
    //    dx = -dx;
    //}
    
    if (cntr == 5) {
        cntr = 0;
        leave1.transform = CGAffineTransformMakeRotation(3.14159265*rotation); //rotation in radians
        leave2.transform = CGAffineTransformMakeRotation(3.14159265*(rotation/2)); //rotation in radians
        leave3.transform = CGAffineTransformMakeRotation(3.14159265*(rotation/2)); //rotation in radians
        leave4.transform = CGAffineTransformMakeRotation(3.14159265*rotation); //rotation in radians
        rotation += .5;
        if (rotation >= 2) {
            rotation = .5;
            if (pos < 0) {
                pos = 1;
            }
            else {
                pos = -1;
            }
        }
        //NSLog(@"rotation: %f",rotation);
    }
	[self bounce];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


- (void)dealloc
{
    [super dealloc];
}

@end

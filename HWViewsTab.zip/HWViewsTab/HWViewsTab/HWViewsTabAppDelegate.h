//
//  HWViewsTabAppDelegate.h
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVAudioPlayer.h>
#import <AudioToolbox/AudioToolbox.h>	//needed for SystemSoundID
@class ButtonSwitchView;

@interface HWViewsTabAppDelegate : NSObject <UIApplicationDelegate, AVAudioPlayerDelegate> {
    MPMoviePlayerController *controller;
    SystemSoundID sid;
    AVAudioPlayer *player;
    ButtonSwitchView *buttonSwitchView;
    NSArray *arr;
    UITabBarController *tabBarController;
	UIWindow *_window;
}

- (void) valueChanged: (id) sender;

- (void) touchUpInside: (id) sender;

- (void) touchUpInside_1: (id) sender;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

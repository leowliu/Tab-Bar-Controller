//
//  FlipView2.m
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FlipView2.h"

@implementation FlipView2

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor blueColor];
        CGRect f = CGRectMake(40, 80, 240, 240);
        imageFlipView2 = [[UIImageView alloc] initWithFrame: f];
        [imageFlipView2 setImage:[UIImage imageNamed: @"freedoSmileywithglasses.png"]];
        imageFlipView2.opaque = YES;
        [self addSubview: imageFlipView2];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
    [super dealloc];
}

@end

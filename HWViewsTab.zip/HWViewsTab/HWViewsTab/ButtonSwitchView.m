//
//  ButtonSwitchView.m
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ButtonSwitchView.h"

@implementation ButtonSwitchView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor whiteColor];
        
		//Do not specify a size for the switch.
		//Let the switch assume its own natural size.
        //Center the button in the view.
		//Center the button in the view.
		CGRect b = self.bounds;
		CGSize s = CGSizeMake(200, 40);	//size of button
		
		CGRect f = CGRectMake(
                              b.origin.x + (b.size.width - s.width) / 2,
                              b.origin.y + (b.size.height - s.height) / 4,
                              s.width,
                              s.height
                              );
        
		audioButton = [UIButton buttonWithType: UIButtonTypeRoundedRect];
		[audioButton retain];
		audioButton.frame = f;
        
		[audioButton setTitleColor: [UIColor redColor] forState: UIControlStateNormal];
		[audioButton setTitle: @"Press Here to Play" forState: UIControlStateNormal];
        
		[audioButton addTarget: [UIApplication sharedApplication].delegate
                        action: @selector(touchUpInside:)
              forControlEvents: UIControlEventTouchUpInside
         ];
        
		[self addSubview: audioButton];
        
		mySwitch = [[UISwitch alloc] initWithFrame: CGRectZero];
		if (mySwitch == nil) {
            NSLog(@"mySwitch is null");
			[self release];
			return nil;
		}
		
		mySwitch.on = NO;	//the default
		
		[mySwitch addTarget: [UIApplication sharedApplication].delegate
                     action: @selector(valueChanged:)
           forControlEvents: UIControlEventValueChanged
         ];
		
		//Center the switch in the SwitchView.
		
		mySwitch.center = CGPointMake(
                                      b.origin.x + b.size.width-50,
                                      b.origin.y + b.size.height / 2
                                      );
		[self addSubview: mySwitch];
        
        UILabel *label = [[UILabel alloc] initWithFrame: CGRectMake(0, b.origin.y+b.size.height/2-16, 220, 30)];
        label.font = [UIFont italicSystemFontOfSize: 20.0f];
        label.backgroundColor = [UIColor yellowColor];
        label.textColor = [UIColor blackColor];
        label.text = @"Press ON Button Play";
        [self addSubview: label];    
        [label release];
        
		//Center the button in the view.
		
		f = CGRectMake(
                       b.origin.x + (b.size.width - s.width - 60),
                       b.origin.y + (b.size.height - s.height - 100),
                       s.width,
                       s.height
                       );
		
		videoButton = [UIButton buttonWithType: UIButtonTypeRoundedRect];
		[videoButton retain];
		videoButton.frame = f;
		
		[videoButton setTitleColor: [UIColor redColor]
                          forState: UIControlStateNormal];
		[videoButton setTitle: @"Press Here to Play"
                     forState: UIControlStateNormal];
		
		[videoButton addTarget: [UIApplication sharedApplication].delegate
                        action: @selector(touchUpInside_1:)
              forControlEvents: UIControlEventTouchUpInside
         ];
		
		[self addSubview: videoButton];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end

//
//  HWViewsTabTests.h
//  HWViewsTabTests
//
//  Created by BENJAMIN LIU on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface HWViewsTabTests : SenTestCase

@end

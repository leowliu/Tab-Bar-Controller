//
//  VCView.h
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VCView : UIView {
	UIImageView *leave1;
    UIImageView *leave2;
    UIImageView *leave3;
    UIImageView *leave4;
	CGFloat dx, dy;	//direction and speed of ball's motion
    CGFloat rotation; // for rotating object
    CGFloat cntr;
    CGFloat pos;
}

- (void) move: (CADisplayLink *) displayLink;

@end

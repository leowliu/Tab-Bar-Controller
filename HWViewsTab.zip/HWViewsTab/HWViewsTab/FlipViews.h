//
//  FlipViews.h
//  HWViewsTab
//
//  Created by BENJAMIN LIU on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlipViews : UIView {
    NSArray *views;
    NSUInteger index;
    NSUInteger newIndex;
    NSUInteger tapCount;
    NSUInteger wearOff;
    NSString *displayText;
    
    CGPoint current0; /* location of touches for pinch/spread */
    CGPoint current1; /* location of touches for pinch/spread */
    CGPoint previous0; /* location of touches for pinch/spread */
    CGPoint previous1; /* location of touches for pinch/spread */
    
    CGPoint pointBegan; /* beginning points of touch for swipe */
    CGPoint pointMoved; /* current points of touch for swipe */
    
    BOOL swipe; /* true if swipe */
    BOOL pinch; /* true if pinch */
}

@end
